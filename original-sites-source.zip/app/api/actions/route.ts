import { identity, readWorkspace, json, database } from '../../../lib/server';
import { mutate } from '../../../lib/domain';
export const dynamic='force-dynamic';
export async function POST(request:Request){
 const origin=request.headers.get('origin');if(!origin||origin!==new URL(request.url).origin)return json({error:'Please submit from this website.'},403);
 if(!request.headers.get('content-type')?.includes('application/json'))return json({error:'Expected JSON.'},415);
 const session=identity(request);
 try{
  const body=await request.text();if(body.length>32000)return json({error:'This request is too large.'},413);
  const action=JSON.parse(body);if(!action||typeof action.type!=='string')return json({error:'Choose an action.'},400);
  const current=await readWorkspace(session.owner);
  if(action.revision!==current.revision)return json({error:'Your farm changed in another tab. We refreshed it; please try again.',workspace:current},409,session.cookie);
  const next=mutate(current,action);delete next.revision;
  const result=await database().prepare('UPDATE workspaces SET data = ?, revision = revision + 1, updated_at = ? WHERE owner = ? AND revision = ?').bind(JSON.stringify(next),new Date().toISOString(),session.owner,current.revision).run();
  if(!result.meta.changes)return json({error:'Another change was saved. Refresh and try again.'},409,session.cookie);
  return json({...next,revision:current.revision+1},200,session.cookie);
 }catch(e){return json({error:e instanceof Error?e.message:'Unable to save. Please retry.'},400,session.cookie);}
}
