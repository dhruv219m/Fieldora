import { identity, readWorkspace, json } from '../../../lib/server';
export const dynamic='force-dynamic';
export async function GET(request:Request){const session=identity(request);try{return json(await readWorkspace(session.owner),200,session.cookie);}catch(e){console.error('workspace read failed',e instanceof Error?e.message:'error');return json({error:'Your farm data could not be loaded. Please retry.'},503,session.cookie);}}
