import { env } from 'cloudflare:workers';
import { seed, type Workspace } from './domain';
export function database(){if(!env.DB)throw new Error('Database is not connected. Please try again shortly.');return env.DB;}
export function identity(request:Request){
 const user=request.headers.get('oai-authenticated-user-id');
 if(user)return {owner:'user:'+user,cookie:null};
 const match=request.headers.get('cookie')?.match(/(?:^|;\s*)ks_demo=([a-f0-9-]{36})(?:;|$)/);
 const key=match?.[1]||crypto.randomUUID();
 return {owner:'guest:'+key,cookie:match?null:`ks_demo=${key}; Path=/; HttpOnly; SameSite=Strict; Max-Age=2592000${new URL(request.url).protocol==='https:'?'; Secure':''}`};
}
export async function readWorkspace(owner:string){
 const db=database();let row=await db.prepare('SELECT data, revision FROM workspaces WHERE owner = ?').bind(owner).first<{data:string;revision:number}>();
 if(!row){await db.prepare('INSERT INTO workspaces (owner, data, revision, updated_at) VALUES (?, ?, 0, ?) ON CONFLICT(owner) DO NOTHING').bind(owner,JSON.stringify(seed()),new Date().toISOString()).run();row=await db.prepare('SELECT data, revision FROM workspaces WHERE owner = ?').bind(owner).first<{data:string;revision:number}>();}
 if(!row)throw new Error('Unable to load your farm.');return {...JSON.parse(row.data),revision:row.revision} as Workspace & {revision:number};
}
export function json(data:unknown,status=200,cookie:string|null=null){const h:Record<string,string>={'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};if(cookie)h['Set-Cookie']=cookie;return new Response(JSON.stringify(data),{status,headers:h});}
